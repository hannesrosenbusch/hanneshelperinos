import time
import json
from datetime import date
from io import BytesIO
from docx import Document
from docx.shared import Inches
from docx.shared import Pt
from docx.oxml.ns import nsdecls
from docx.oxml import parse_xml
from docx.enum.text import WD_ALIGN_PARAGRAPH # pylint: disable=E0611
from docx.shared import RGBColor
import requests
import base64
import ast

def lambda_handler(event, context):
    # TODO implement
    #data = json.loads(event["body"])
    data = event["body"]
    #posted_data = {'raw_survey': '{"_id":"6244325f952d8c0013db1226","active":false,"approved":true,"profilePriority":0,"finished":true,"shuffleBlocks":false,"tracking":false,"userCounter":7500,"languageGroups":["en"],"filterExits":[],"sample":"none","skipSum":0,"surveyMonkeyIds":[],"withWebapp":false,"surveyType":"surveyAdmin","quotation":[{"conditionsGeneralSnapshot":{"age":[{"min":35,"max":44}],"gender":"m","countryCode":["GBR"]},"maxUser":0},{"conditionsGeneralSnapshot":{"age":[{"min":16,"max":24}],"gender":"m","countryCode":["GBR"]},"maxUser":0},{"conditionsGeneralSnapshot":{"age":[{"min":16,"max":24}],"gender":"f","countryCode":["GBR"]},"maxUser":0},{"conditionsGeneralSnapshot":{"age":[{"min":25,"max":34}],"gender":"m","countryCode":["GBR"]},"maxUser":0},{"conditionsGeneralSnapshot":{"age":[{"min":25,"max":34}],"gender":"f","countryCode":["GBR"]},"maxUser":0},{"conditionsGeneralSnapshot":{"age":[{"min":35,"max":44}],"gender":"f","countryCode":["GBR"]},"maxUser":0},{"conditionsGeneralSnapshot":{"age":[{"min":45,"max":54}],"gender":"m","countryCode":["GBR"]},"maxUser":0},{"conditionsGeneralSnapshot":{"age":[{"min":45,"max":54}],"gender":"f","countryCode":["GBR"]},"maxUser":0},{"conditionsGeneralSnapshot":{"age":[{"min":55,"max":65}],"gender":"m","countryCode":["GBR"]},"maxUser":0},{"conditionsGeneralSnapshot":{"age":[{"min":55,"max":65}],"gender":"f","countryCode":["GBR"]},"maxUser":0}],"enddate":"2032-03-30T00:00:00.000Z","company":"61698d57719dbb00134dcf8f","maxParticipants":7500,"startdate":"2022-03-30T10:35:11.532Z","questions":[{"hideForCompany":false,"filterRequirements":[],"filterNotRequirements":[],"_id":"62448fc9875b8c0009004318","qtype":"mc","text":"Filter","answers":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"62448fc9875b8c0009004319","text":"GBR","exclusiveAnswer":false,"filterId":"8ZWMVHzr","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"62448fc9875b8c000900431a","text":"USA","exclusiveAnswer":false,"filterId":"8iLik15z","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"62448fc9875b8c000900431b","text":"GER","exclusiveAnswer":false,"filterId":"LKQSc4jX","random":false,"correctAnswer":false}],"allowCustomText":false,"multioptions":false,"filterId":"SvTqG2Ov","displayGroup":0,"rows":[],"key":[]},{"hideForCompany":false,"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1228","qtype":"mc","text":"How many inhabitants live in your place of residence?","answers":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1229","text":"Less than 50,000 people","exclusiveAnswer":false,"filterId":"NS7sqCOo","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db122a","text":"50,001 to 250,000 people","exclusiveAnswer":false,"filterId":"a817u4ag","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db122b","text":"250,001 to 750,000 people","exclusiveAnswer":false,"filterId":"xXgDyage","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db122c","text":"750,001 to 1,500,000 people","exclusiveAnswer":false,"filterId":"naft37cL","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db122d","text":"More than 1,500,000","exclusiveAnswer":false,"filterId":"If7vk0ez","random":false,"correctAnswer":false}],"allowCustomText":false,"multioptions":false,"filterId":"xhzICD5m","displayGroup":0,"rows":[],"key":[]},{"hideForCompany":false,"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db122e","qtype":"mc","text":"How far away is the supermarket you shop at most often? (whether by foot/car etc.)","answers":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db122f","text":"Less than 5 min / Less than 1 mile","exclusiveAnswer":false,"filterId":"fRHAKV6f","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1230","text":"5-10 min / Up to 5 miles","exclusiveAnswer":false,"filterId":"CK4qPSdq","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1231","text":"11-20 min / Up to 10 miles","exclusiveAnswer":false,"filterId":"9NKeeE5A","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1232","text":"More than 20 min / More than 10 miles away","exclusiveAnswer":false,"filterId":"7pEdfX5B","random":false,"correctAnswer":false}],"allowCustomText":false,"multioptions":false,"filterId":"74kZGb7c","displayGroup":0,"rows":[],"key":[]},{"hideForCompany":false,"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1233","qtype":"mc","text":"What is grocery shopping at the supermarket for you? \\"Shopping for me is...\\"","answers":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1234","text":"Unpleasant / a chore that must be done","exclusiveAnswer":false,"filterId":"XFA57fEJ","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1235","text":"Pleasant / a pleasant experience","exclusiveAnswer":false,"filterId":"Ra2Qx2im","random":true,"correctAnswer":false}],"allowCustomText":false,"multioptions":false,"filterId":"Kik8OoVR","displayGroup":0,"rows":[],"key":[]},{"hideForCompany":false,"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1236","qtype":"mc","text":"How do you currently buy your groceries?","answers":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1237","text":"Locally at the bricks-and-mortar stores only","exclusiveAnswer":false,"filterId":"BNbibxca","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1238","text":"Mainly in-store, partly online","exclusiveAnswer":false,"filterId":"47EoZsOX","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1239","text":"Mainly online, partly in-store","exclusiveAnswer":false,"filterId":"z2NMUZK2","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db123a","text":"Exclusively online","exclusiveAnswer":false,"filterId":"G71w1XSC","random":false,"correctAnswer":false}],"allowCustomText":false,"multioptions":false,"filterId":"z2J5FEck","displayGroup":0,"rows":[],"key":[]},{"hideForCompany":false,"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db123b","qtype":"distribution","text":"How has your household\'s food spending been distributed among the following channels in the last 6 months?","answers":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db123c","text":"In-store","filterId":"h3dfdcQU","correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db123d","text":"Online with home delivery","filterId":"meti1xAb","correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db123e","text":"Online with Click and Collect","filterId":"tJeKI4V5","correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db123f","text":"Other Channels","filterId":"hKibF0kJ","correctAnswer":false}],"filterId":"LY68I1lI","help":"[Choose % / needs to total to 100%]","minRange":1,"displayGroup":0,"rows":[],"key":[]},{"hideForCompany":false,"filterRequirements":["BNbibxca"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1240","qtype":"likert","text":"In principle, can you imagine ordering groceries online at some point in the future?","filterId":"fZgSh6Gz","key":[{"_id":"62448fccd5a1010007eb4161","num":1,"text":"No","filterId":"VWYqDA9y"},{"_id":"62448fccd5a1010007eb4162","num":2,"text":"Rather no","filterId":"pwYpMzOy"},{"_id":"62448fccd5a1010007eb4163","num":3,"text":"Rather yes","filterId":"VEeX9VuR"},{"_id":"62448fccd5a1010007eb4164","num":4,"text":"Yes","filterId":"gGzdjlwH"}],"maxRange":4,"minRange":1,"stepRange":1,"displayGroup":0,"answers":[],"rows":[]},{"hideForCompany":false,"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1245","qtype":"matrix","text":"How likely are the following to motivate you to order groceries online (more often)?","answers":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1246","text":"Very likely","excludeAnswer":false,"filterId":"VESacvdL","correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1247","text":"Somewhat likely","excludeAnswer":false,"filterId":"69ptSxia","correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1248","text":"Rather unlikely","excludeAnswer":false,"filterId":"GlrdUj2A","correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1249","text":"Very unlikely","excludeAnswer":false,"filterId":"bah1w5VT","correctAnswer":false}],"filterId":"iPeWFcrD","displayGroup":0,"rows":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db124a","text":"Better availability in location","filterId":"C7xke2t7","imageUrl":"","random":true},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db124b","text":"Faster delivery","filterId":"lLnna0mT","imageUrl":"","random":true},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db124c","text":"Cheaper prices","filterId":"n2iRyXw2","imageUrl":"","random":true},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db124d","text":"Larger assortment","filterId":"vJVLUdVM","imageUrl":"","random":true},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db124e","text":"Ease of use","filterId":"qD10F27L","imageUrl":"","random":true},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db124f","text":"More sustainable offering","filterId":"I95F1Vck","imageUrl":"","random":true}],"key":[]},{"hideForCompany":false,"filterRequirements":["47EoZsOX","z2NMUZK2","G71w1XSC"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1250","qtype":"matrix","text":"When you compare online and offline grocery shopping, where do you think the following criteria are better solved overall?","answers":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1251","text":"Offline much better","excludeAnswer":false,"filterId":"QBsqQMRP","correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1252","text":"Offline slightly better","excludeAnswer":false,"filterId":"kVO31vQE","correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1253","text":"No difference","excludeAnswer":false,"filterId":"UL8z2DOh","correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1254","text":"Online much better","excludeAnswer":false,"filterId":"mXZwFHRt","correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1255","text":"Online slightly better","excludeAnswer":false,"filterId":"AfYgxLRQ","correctAnswer":false}],"filterId":"lltX8afn","displayGroup":0,"rows":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1256","text":"Overall shopping experience","filterId":"mreM2M7R","imageUrl":"","random":true},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1257","text":"Food selection","filterId":"MiIBUCyO","imageUrl":"","random":true},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1258","text":"Food availability","filterId":"EyPlJ9Qv","imageUrl":"","random":true},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1259","text":"Value for money","filterId":"y7WnGjtH","imageUrl":"","random":true},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db125a","text":"Customer Service","filterId":"WNhmo8Vb","imageUrl":"","random":true},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db125b","text":"Quality of food","filterId":"1izIy5Cv","imageUrl":"","random":true}],"key":[]},{"hideForCompany":false,"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db125c","qtype":"mc","text":"For which category of vendors do you think an online grocery ordering offer is a good idea?","answers":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db125d","text":"Supermarkets","exclusiveAnswer":false,"filterId":"A2cBXGjd","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db125e","text":"Low Cost Supermarket","exclusiveAnswer":false,"filterId":"PTDK8VTf","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db125f","text":"Organic Shops","exclusiveAnswer":false,"filterId":"tCKfBhDt","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1260","text":"Local Suppliers (markets, farmers)","exclusiveAnswer":false,"filterId":"l6rPXss6","random":true,"correctAnswer":false}],"allowCustomText":true,"customTextName":"Other, namely:","multioptions":true,"filterId":"6uCJiYDX","displayGroup":0,"rows":[],"key":[]},{"hideForCompany":false,"filterRequirements":["47EoZsOX","z2NMUZK2","G71w1XSC"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1261","qtype":"mc","text":"How much do you spend on average per week on groceries you order <b>online</b>?","answers":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1262","text":"Less than £/$/€ 20","exclusiveAnswer":false,"filterId":"iMjXGdhw","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1263","text":"Between £/$€ 20 - £50","exclusiveAnswer":false,"filterId":"vM4QibD1","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1264","text":"Between £/$/€ 51 - £100","exclusiveAnswer":false,"filterId":"555jS10I","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1265","text":"Between £/$/€ 101 - £200","exclusiveAnswer":false,"filterId":"iGwJCSWz","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1266","text":"More than £/$/€ 201","exclusiveAnswer":false,"filterId":"3abAC60E","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"624453c47e359800081d765b","text":"Not sure","exclusiveAnswer":false,"filterId":"bJ8v9cHz","random":false,"correctAnswer":false}],"allowCustomText":false,"multioptions":false,"filterId":"UVddoESA","displayGroup":0,"rows":[],"key":[]},{"hideForCompany":false,"filterRequirements":["BNbibxca","47EoZsOX","z2NMUZK2"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1267","qtype":"mc","text":"How much do you spend on average per week on food that you buy <b>offline</b> (e.g. supermarket, discount store, weekly market)","answers":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1268","text":"Less than £/$/€ 20","exclusiveAnswer":false,"filterId":"9YQ5xfIF","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1269","text":"Between £/$/€ 20 - £50","exclusiveAnswer":false,"filterId":"7RQIaHEC","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db126a","text":"Between £/$/€ 51 - £100","exclusiveAnswer":false,"filterId":"QVcPzwfx","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db126b","text":"Between £/$/€ 101 - £200","exclusiveAnswer":false,"filterId":"JNpS1kHF","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db126c","text":"More than £/$/€ 201","exclusiveAnswer":false,"filterId":"oCfvcabO","random":false,"correctAnswer":false}],"allowCustomText":false,"multioptions":false,"filterId":"xLvaC4YO","displayGroup":0,"rows":[],"key":[]},{"hideForCompany":false,"filterRequirements":["47EoZsOX","z2NMUZK2"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db126d","qtype":"matrix","text":"If you buy more groceries online than usual in a month, how does your buying behavior change with other vendors?","answers":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db126e","text":"I spend more","excludeAnswer":false,"filterId":"zFAsal5M","correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db126f","text":"I spend the same","excludeAnswer":false,"filterId":"PKDT26Op","correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1270","text":"I spend a little less","excludeAnswer":false,"filterId":"3psmGRPU","correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1271","text":"I spend much less","excludeAnswer":false,"filterId":"Fs97WlDg","correctAnswer":false}],"filterId":"Fm25FNPn","displayGroup":0,"rows":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1272","text":"Supermarkets","filterId":"y8SN4gjS","imageUrl":"","random":true},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1273","text":"Low Cost Supermarket","filterId":"CwFzJmYl","imageUrl":"","random":true},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1274","text":"Local markets, farmers","filterId":"hbtRbap2","imageUrl":"","random":true},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1275","text":"Restaurants/delivery services","filterId":"7xZ1YiaL","imageUrl":"","random":true},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1276","text":"Health food stores","filterId":"QgRtDkor","imageUrl":"","random":true}],"key":[]},{"hideForCompany":false,"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1277","qtype":"mc","text":"How do you envision your grocery shopping in 2 years?","answers":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1278","text":"Locally at the bricks-and-mortar stores only","exclusiveAnswer":false,"filterId":"sMC2p09U","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1279","text":"Mainly in-store, partly online","exclusiveAnswer":false,"filterId":"Qqf2w8Tn","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db127a","text":"Mainly online, partly in-store","exclusiveAnswer":false,"filterId":"033TlUDo","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db127b","text":"Exclusively online","exclusiveAnswer":false,"filterId":"EWrrIlbD","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"62443bf87e359800081c6c11","text":"(USA) Things are evolving so quickly, I am not sure how to answer","exclusiveAnswer":false,"filterId":"jkUoEL5r","random":false,"correctAnswer":false}],"allowCustomText":false,"multioptions":false,"filterId":"K7DcFnAJ","displayGroup":0,"rows":[],"key":[]},{"hideForCompany":false,"filterRequirements":["47EoZsOX","z2NMUZK2","G71w1XSC"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db127c","qtype":"freetext","text":"What online grocery delivery services do you know?","filterId":"62BN9P6E","displayGroup":0,"answers":[],"rows":[],"key":[]},{"hideForCompany":false,"filterRequirements":["47EoZsOX","z2NMUZK2","G71w1XSC"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db127d","qtype":"mc","text":"[BRANDS UK/ALL] We want to know a little more. Which of these online food delivery services do you know, even if only by name?","answers":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db127e","text":"Amazon Fresh (All)","exclusiveAnswer":false,"filterId":"IzOiW8vx","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db127f","text":"Hello Fresh (All)","exclusiveAnswer":false,"filterId":"fkXQNq6y","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1280","text":"Gousto","exclusiveAnswer":false,"filterId":"x2J7pNMM","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1281","text":"Mindful Chef","exclusiveAnswer":false,"filterId":"NY5UWslS","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1282","text":"Deliveroo","exclusiveAnswer":false,"filterId":"Q5hmzilI","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1283","text":"Just Eat","exclusiveAnswer":false,"filterId":"bNaX1wmh","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1284","text":"Uber Eats","exclusiveAnswer":false,"filterId":"QAFNjOlj","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1285","text":"OddBox","exclusiveAnswer":false,"filterId":"JZVaLeWJ","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1286","text":"Abel & Cole","exclusiveAnswer":false,"filterId":"AveG2n77","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1287","text":"Foodhub","exclusiveAnswer":false,"filterId":"T6CHswRb","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1288","text":"Getir (UK, Ger)","exclusiveAnswer":false,"filterId":"fp7kvay2","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1289","text":"Gorillas (UK, Ger)","exclusiveAnswer":false,"filterId":"8dq8VULb","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db128a","text":"Zapp","exclusiveAnswer":false,"filterId":"kRfYyBZN","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db128b","text":"GoPuff (UK, US)","exclusiveAnswer":false,"filterId":"iN6tpglT","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db128c","text":"Milk & More","exclusiveAnswer":false,"filterId":"DykOr6nU","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db128d","text":"Dija","exclusiveAnswer":false,"filterId":"pOgNFTWN","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db128e","text":"Grocemania","exclusiveAnswer":false,"filterId":"HLDgoR85","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db128f","text":"Jiffy Groceries","exclusiveAnswer":false,"filterId":"xPq0OwsA","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1290","text":"Weezy","exclusiveAnswer":false,"filterId":"PFlzJ1Wl","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1291","text":"Beelivery","exclusiveAnswer":false,"filterId":"pASMNbBf","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1292","text":"Stuart","exclusiveAnswer":false,"filterId":"KTjYTZcW","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"62443d3f7e359800081c6eee","text":"None of these","exclusiveAnswer":false,"filterId":"P3L4O2Ht","random":false,"correctAnswer":false}],"allowCustomText":true,"customTextName":"Other:","multioptions":true,"filterId":"WGnVuAfu","displayGroup":0,"rows":[],"key":[]},{"hideForCompany":false,"filterRequirements":[],"filterNotRequirements":[],"_id":"62443dbff801e70009534c1d","qtype":"mc","text":"[BRANDS US/GER] We want to know a little more. Which of these online food delivery services do you know, even if only by name?","answers":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"62443dbff801e70009534c1e","text":"Rewe Online","exclusiveAnswer":false,"filterId":"YHd0Z2IC","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"62443dbff801e70009534c1f","text":"Flink","exclusiveAnswer":false,"filterId":"94mrYMtG","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"62443dbff801e70009534c20","text":"Frische Paradies","exclusiveAnswer":false,"filterId":"x0HGNl6B","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"62443dbff801e70009534c21","text":"myTime","exclusiveAnswer":false,"filterId":"AE1U7h7b","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"62443dbff801e70009534c22","text":"Edeka24","exclusiveAnswer":false,"filterId":"JZgT43bj","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"62443dbff801e70009534c23","text":"alles-vegetarisch.de","exclusiveAnswer":false,"filterId":"hbNukpn5","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"62443dbff801e70009534c24","text":"Wolt","exclusiveAnswer":false,"filterId":"0h6wZgZc","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"62443dbff801e70009534c25","text":"Bringemeister","exclusiveAnswer":false,"filterId":"BULfTysi","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"62443dbff801e70009534c26","text":"Picnic","exclusiveAnswer":false,"filterId":"GyTLfcdc","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"62443dbff801e70009534c27","text":"knuspr","exclusiveAnswer":false,"filterId":"3GYGF7vp","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"62443dbff801e70009534c28","text":"BlueAppron (US)","exclusiveAnswer":false,"filterId":"NaEuGDv4","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"62443dbff801e70009534c29","text":"Instacart (US)","exclusiveAnswer":false,"filterId":"CKxtFp8X","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"62443dbff801e70009534c2a","text":"Doordash (US)","exclusiveAnswer":false,"filterId":"cs3992rX","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"62443dbff801e70009534c2b","text":"Postmates (US)","exclusiveAnswer":false,"filterId":"DmAEKUhN","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"62443dbff801e70009534c2c","text":"Farmesteadapp (US)","exclusiveAnswer":false,"filterId":"UOZBhrSS","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"62443dbff801e70009534c2d","text":"GrubHub (US)","exclusiveAnswer":false,"filterId":"3UAwZheZ","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"62443dbff801e70009534c2e","text":"Delivery.com (US)","exclusiveAnswer":false,"filterId":"rMZisHUu","random":true,"correctAnswer":false}],"allowCustomText":false,"multioptions":true,"filterId":"SP4AHwja","displayGroup":0,"rows":[],"key":[]},{"hideForCompany":false,"filterRequirements":["IzOiW8vx","fkXQNq6y","x2J7pNMM","NY5UWslS","Q5hmzilI","bNaX1wmh","QAFNjOlj","JZVaLeWJ","AveG2n77","T6CHswRb"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1293","qtype":"matrix","text":"Please indicate what experience you have had with the following online grocery delivery services:","answers":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1294","text":"Never tried","excludeAnswer":false,"filterId":"iT0I1IM1","correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1295","text":"Used it, but not anymore","excludeAnswer":false,"filterId":"Gxi4umQ8","correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1296","text":"Use it occasionally","excludeAnswer":false,"filterId":"YgOhhZhe","correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1297","text":"Use it regularly","excludeAnswer":false,"filterId":"j99XPIJG","correctAnswer":false}],"filterId":"n0m4gotm","displayGroup":0,"rows":[{"filterRequirements":["IzOiW8vx"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1298","text":"Amazon Fresh","filterId":"qU53vfnL","imageUrl":"","random":true},{"filterRequirements":["fkXQNq6y"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db1299","text":"Hello Fresh","filterId":"W5gEQvTM","imageUrl":"","random":true},{"filterRequirements":["x2J7pNMM"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db129a","text":"Gousto","filterId":"LyugD0sw","imageUrl":"","random":true},{"filterRequirements":["NY5UWslS"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db129b","text":"Mindful Chef","filterId":"zya28w0v","imageUrl":"","random":true},{"filterRequirements":["Q5hmzilI"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db129c","text":"Deliveroo","filterId":"UX8xTVep","imageUrl":"","random":true},{"filterRequirements":["bNaX1wmh"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db129d","text":"Just Eat","filterId":"CerS8Bev","imageUrl":"","random":true},{"filterRequirements":["QAFNjOlj"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db129e","text":"Uber Eats","filterId":"L6mwWxb1","imageUrl":"","random":true},{"filterRequirements":["JZVaLeWJ"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db129f","text":"OddBox","filterId":"kLPfLvUs","imageUrl":"","random":true},{"filterRequirements":["AveG2n77"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12a0","text":"Abel & Cole","filterId":"IlcPx45x","imageUrl":"","random":true},{"filterRequirements":["T6CHswRb"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12a1","text":"Foodhub","filterId":"NTHsJzlI","imageUrl":"","random":true}],"key":[]},{"hideForCompany":false,"filterRequirements":["fp7kvay2","8dq8VULb","kRfYyBZN","iN6tpglT","DykOr6nU","pOgNFTWN","HLDgoR85","xPq0OwsA","PFlzJ1Wl","pASMNbBf","KTjYTZcW"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12a2","qtype":"matrix","text":"Please indicate what experience you have had with the following online grocery delivery services:","answers":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12a3","text":"Never tried","excludeAnswer":false,"filterId":"Gif4AmLm","correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12a4","text":"Used it, but not anymore","excludeAnswer":false,"filterId":"86AXTTSU","correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12a5","text":"Use it occasionally","excludeAnswer":false,"filterId":"FwylADDw","correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12a6","text":"Use it regularly","excludeAnswer":false,"filterId":"lME22BWG","correctAnswer":false}],"filterId":"XT7QmCp7","displayGroup":0,"rows":[{"filterRequirements":["fp7kvay2"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12a7","text":"Getir","filterId":"jpl1wQtZ","imageUrl":"","random":true},{"filterRequirements":["8dq8VULb"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12a8","text":"Gorillas","filterId":"BdFVs9CF","imageUrl":"","random":true},{"filterRequirements":["kRfYyBZN"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12a9","text":"Zapp","filterId":"iavHsxS9","imageUrl":"","random":true},{"filterRequirements":["iN6tpglT"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12aa","text":"GoPuff","filterId":"VszwZh37","imageUrl":"","random":true},{"filterRequirements":["DykOr6nU"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12ab","text":"Milk & More","filterId":"9fXFFrJY","imageUrl":"","random":true},{"filterRequirements":["pOgNFTWN"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12ac","text":"Dija","filterId":"X0uNuT5g","imageUrl":"","random":true},{"filterRequirements":["HLDgoR85"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12ad","text":"Grocemania","filterId":"GcZ3nWkx","imageUrl":"","random":true},{"filterRequirements":["xPq0OwsA"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12ae","text":"Jiffy Groceries","filterId":"lGy2B2f1","imageUrl":"","random":true},{"filterRequirements":["PFlzJ1Wl"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12af","text":"Weezy","filterId":"ntlmjyVj","imageUrl":"","random":true},{"filterRequirements":["pASMNbBf"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12b0","text":"Beelivery","filterId":"NhQj3q3a","imageUrl":"","random":true},{"filterRequirements":["KTjYTZcW"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12b1","text":"Stuart","filterId":"AFcbfwuA","imageUrl":"","random":true}],"key":[]},{"hideForCompany":false,"filterRequirements":[],"filterNotRequirements":[],"_id":"6244413f7e359800081c83d8","qtype":"matrix","text":"[GER] Please indicate what experience you have had with the following online grocery delivery services:","answers":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244413f7e359800081c83d9","text":"Never tried","excludeAnswer":false,"filterId":"8HfPu8xX","correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244413f7e359800081c83da","text":"Used it, but not anymore","excludeAnswer":false,"filterId":"NL0dtOA1","correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244413f7e359800081c83db","text":"Use it occasionally","excludeAnswer":false,"filterId":"V286tyF8","correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244413f7e359800081c83dc","text":"Use it regularly","excludeAnswer":false,"filterId":"kqfKKGhh","correctAnswer":false}],"filterId":"Hx4PFcyb","displayGroup":0,"rows":[{"filterRequirements":["fp7kvay2"],"filterNotRequirements":[],"_id":"6244413f7e359800081c83dd","text":"Rewe Online","filterId":"4KuEmBi9","imageUrl":"","random":true},{"filterRequirements":["8dq8VULb"],"filterNotRequirements":[],"_id":"6244413f7e359800081c83de","text":"Flink","filterId":"tQuCqsIJ","imageUrl":"","random":true},{"filterRequirements":["kRfYyBZN"],"filterNotRequirements":[],"_id":"6244413f7e359800081c83df","text":"Frische Paradies","filterId":"YHYy6TBA","imageUrl":"","random":true},{"filterRequirements":["iN6tpglT"],"filterNotRequirements":[],"_id":"6244413f7e359800081c83e0","text":"myTime","filterId":"BN7QNUso","imageUrl":"","random":true},{"filterRequirements":["DykOr6nU"],"filterNotRequirements":[],"_id":"6244413f7e359800081c83e1","text":"Edeka24","filterId":"EVtSOXAn","imageUrl":"","random":true},{"filterRequirements":["pOgNFTWN"],"filterNotRequirements":[],"_id":"6244413f7e359800081c83e2","text":"alles-vegetarisch.de","filterId":"qJkYNXvb","imageUrl":"","random":true},{"filterRequirements":["HLDgoR85"],"filterNotRequirements":[],"_id":"6244413f7e359800081c83e3","text":"Wolt","filterId":"Gxa89gYY","imageUrl":"","random":true},{"filterRequirements":["xPq0OwsA"],"filterNotRequirements":[],"_id":"6244413f7e359800081c83e4","text":"Bringmeister","filterId":"V0QC0MFm","imageUrl":"","random":true},{"filterRequirements":["PFlzJ1Wl"],"filterNotRequirements":[],"_id":"6244413f7e359800081c83e5","text":"Picnic","filterId":"gllqFnjM","imageUrl":"","random":true},{"filterRequirements":[],"filterNotRequirements":[],"_id":"62447eced0ee4d00081dfbb3","text":"knuspr","filterId":"cwFwGWa1","random":true}],"key":[]},{"hideForCompany":false,"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12b2","qtype":"mc","text":"How often / do you ever order DIY meal boxes?  (eg. Hello Fresh / Gousto)","answers":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12b3","text":"Weekly","exclusiveAnswer":false,"filterId":"BjOx5V9g","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12b4","text":"Several times a month","exclusiveAnswer":false,"filterId":"5uogi6iD","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12b5","text":"Monthly","exclusiveAnswer":false,"filterId":"VigLoo6v","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12b6","text":"Every few months","exclusiveAnswer":false,"filterId":"mGAXgqSE","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12b7","text":"Once a year or less","exclusiveAnswer":false,"filterId":"lCdNg9lL","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12b8","text":"Never","exclusiveAnswer":false,"filterId":"5gywM7yE","random":false,"correctAnswer":false}],"allowCustomText":false,"multioptions":false,"filterId":"MUrQJgXe","displayGroup":0,"rows":[],"key":[]},{"hideForCompany":false,"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12b9","qtype":"mc","text":"Which companies would you like to see offer online food ordering?","answers":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12ba","text":"Aldi","exclusiveAnswer":false,"filterId":"tFP6NtLX","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12bb","text":"Lidl","exclusiveAnswer":false,"filterId":"3UJI5DN2","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12bc","text":"M&S","exclusiveAnswer":false,"filterId":"NJBgJsiJ","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12bd","text":"Co-op","exclusiveAnswer":false,"filterId":"SmeoNDZ2","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12be","text":"Netto","exclusiveAnswer":true,"filterId":"xG35oKDh","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244432bf801e70009536442","text":"Penny","exclusiveAnswer":false,"filterId":"uhht4IRM","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244432bf801e7000953644c","text":"Norma","exclusiveAnswer":false,"filterId":"wunIF2zm","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244432bf801e7000953645d","text":"Denn\'s / Dennree","exclusiveAnswer":false,"filterId":"JPMsu53B","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244432bf801e70009536460","text":"Alnatura","exclusiveAnswer":false,"filterId":"zb8a1lSq","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244432bf801e70009536463","text":"BioCompany","exclusiveAnswer":false,"filterId":"LZjo6ZoS","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244432bf801e70009536466","text":"None of the above","exclusiveAnswer":false,"filterId":"8iJ6sCvz","random":false,"correctAnswer":false}],"allowCustomText":true,"customTextName":"Other, namely:","multioptions":true,"filterId":"BWumjPe8","displayGroup":0,"rows":[],"key":[]},{"hideForCompany":false,"filterRequirements":["47EoZsOX","z2NMUZK2","G71w1XSC"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12bf","qtype":"mc","text":"Which of the following negative experiences have you had while grocery shopping online?","answers":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12c0","text":"I couldn\'t find a matching delivery slot","exclusiveAnswer":false,"filterId":"mXZH7LVw","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12c1","text":"I felt like the groceries didn\'t get to my house fresh enough","exclusiveAnswer":false,"filterId":"dz4s5cGT","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12c2","text":"The delivery did not arrive at the requested delivery slot","exclusiveAnswer":false,"filterId":"23KQXqEp","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12c3","text":"Too many substituted items","exclusiveAnswer":false,"filterId":"5XtI3MBS","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12c4","text":"The minimum order value was too high for me","exclusiveAnswer":false,"filterId":"1i4QQXx2","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12c5","text":"The delivery charge was too high","exclusiveAnswer":false,"filterId":"t6hmrFpY","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12c6","text":"I haven\'t had any negative experiences","exclusiveAnswer":true,"filterId":"ElvO1f4N","random":false,"correctAnswer":false}],"allowCustomText":true,"customTextName":"Other:","multioptions":true,"filterId":"7NMuTKuI","displayGroup":0,"rows":[],"key":[]},{"hideForCompany":false,"filterRequirements":["47EoZsOX","z2NMUZK2","G71w1XSC"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12c7","qtype":"mc","text":"Which of the following situations apply to you? <br></br>\\"I order groceries online...\\"","answers":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12c8","text":"When I spontaneously miss an ingredient while cooking","exclusiveAnswer":false,"filterId":"ogVoNhnH","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12c9","text":"When I\'m at home and too lazy to leave the house","exclusiveAnswer":false,"filterId":"FoJRPunv","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12ca","text":"When I don\'t have time to go shopping","exclusiveAnswer":false,"filterId":"m6tn4nar","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12cb","text":"To do all the weekly shopping","exclusiveAnswer":false,"filterId":"VYYI9BPT","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12cc","text":"In order not to have to go into a store (e.g. avoid crowds or risk of infection)","exclusiveAnswer":false,"filterId":"bThdsdES","random":true,"correctAnswer":false}],"allowCustomText":true,"customTextName":"Other situations / reasons:","multioptions":true,"filterId":"KvXHFyBH","displayGroup":0,"rows":[],"key":[]},{"hideForCompany":false,"filterRequirements":["47EoZsOX","z2NMUZK2","G71w1XSC"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12cd","qtype":"mc","text":"Which of the following product categories do you shop online?","answers":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12ce","text":"Pharmacy products","exclusiveAnswer":false,"filterId":"9Fb1T6I9","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12cf","text":"Sweets and snacks","exclusiveAnswer":false,"filterId":"mIEKI91o","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12d0","text":"Beverages","exclusiveAnswer":false,"filterId":"j3S1qjKl","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12d1","text":"Dry goods such as pasta, rice","exclusiveAnswer":false,"filterId":"YzCkkBJE","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12d2","text":"Ready Meals","exclusiveAnswer":false,"filterId":"0XjLKjdP","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12d3","text":"Fruit and vegetables","exclusiveAnswer":false,"filterId":"dYxnxrtm","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12d4","text":"Frozen products","exclusiveAnswer":false,"filterId":"iiHR7rnC","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12d5","text":"Dairy products (yogurt, milk, etc.)","exclusiveAnswer":false,"filterId":"AcLoPXw3","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12d6","text":"Fresh meat and fish","exclusiveAnswer":false,"filterId":"DoTKaz3O","random":true,"correctAnswer":false}],"allowCustomText":false,"multioptions":true,"filterId":"NzrVw7xi","displayGroup":0,"rows":[],"key":[]},{"hideForCompany":false,"filterRequirements":["47EoZsOX","z2NMUZK2","G71w1XSC"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12d7","qtype":"matrix","text":"When you order groceries online, how important is it to you that the vendor offers the following?","answers":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12d8","text":"Not important at all","excludeAnswer":false,"filterId":"tIie2HlF","correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12d9","text":"Rather unimportant","excludeAnswer":false,"filterId":"j3buA0b9","correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12da","text":"Slightly important","excludeAnswer":false,"filterId":"IrJx4DCZ","correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12db","text":"Very important","excludeAnswer":false,"filterId":"3GqxgyzX","correctAnswer":false}],"filterId":"qaXu87I5","displayGroup":0,"rows":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12dc","text":"Good assortment","filterId":"N65RkP6F","imageUrl":"","random":true},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12dd","text":"Convenient delivery times","filterId":"QKjiSl3g","imageUrl":"","random":true},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12de","text":"Low order fees / delivery costs","filterId":"6IIsPeQC","imageUrl":"","random":true},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12df","text":"Fresh products","filterId":"zj9E6GcK","imageUrl":"","random":true},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12e0","text":"Order Tracking / Delivery Notification","filterId":"TxJDNp2v","imageUrl":"","random":true},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12e1","text":"Fast and reliable customer service","filterId":"eXQODeSX","imageUrl":"","random":true},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12e2","text":"Easy-to-use platform / user-friendly shopping experience","filterId":"s6xryMQF","imageUrl":"","random":true},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12e3","text":"That the staff / riders are treated well","filterId":"DLCdn1pl","imageUrl":"","random":true},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12e4","text":"Reviews and product information","filterId":"ksNeYwgq","imageUrl":"","random":true},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12e5","text":"Organised shopping lists / a subscription model","filterId":"6NouTFAi","imageUrl":"","random":true},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12e6","text":"Personalised Promotions","filterId":"8Ry7egGf","imageUrl":"","random":true},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12e7","text":"Sustainable products","filterId":"7cFL3AeP","imageUrl":"","random":true}],"key":[]},{"hideForCompany":false,"filterRequirements":["47EoZsOX","z2NMUZK2","G71w1XSC"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12e8","qtype":"mc","text":"How many different platforms / services do you use to order groceries online?","answers":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12e9","text":"1","exclusiveAnswer":false,"filterId":"0q816tea","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12ea","text":"2","exclusiveAnswer":false,"filterId":"Jet7kdBx","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12eb","text":"3","exclusiveAnswer":false,"filterId":"z6BqYS6k","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12ec","text":"More than 4","exclusiveAnswer":false,"filterId":"kuYrAG7a","random":false,"correctAnswer":false}],"allowCustomText":false,"multioptions":false,"filterId":"kC86aQ3n","displayGroup":0,"rows":[],"key":[]},{"hideForCompany":false,"filterRequirements":["47EoZsOX","z2NMUZK2","G71w1XSC"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12ed","qtype":"mc","text":"Which of the following sentences is most true of you when you order your online groceries ?","answers":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12ee","text":"I place Individual orders as an when I need to","exclusiveAnswer":false,"filterId":"HyLkyhqJ","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12ef","text":"I have a subscription for regular deliveries","exclusiveAnswer":false,"filterId":"eBMf7rJb","random":false,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12f0","text":"I do both","exclusiveAnswer":false,"filterId":"GLU83kWG","random":false,"correctAnswer":false}],"allowCustomText":false,"multioptions":false,"filterId":"T4yITj2e","displayGroup":0,"rows":[],"key":[]},{"hideForCompany":false,"filterRequirements":["47EoZsOX","z2NMUZK2","G71w1XSC"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12f1","qtype":"mc","text":"Which option do you prefer for groceries purchased online?","answers":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12f2","text":"Click & Collect","exclusiveAnswer":false,"filterId":"6inZHMNs","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12f3","text":"Delivery ASAP","exclusiveAnswer":false,"filterId":"8o6QshWv","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12f4","text":"Delivery at a later date","exclusiveAnswer":false,"filterId":"elputlKR","random":true,"correctAnswer":false}],"allowCustomText":true,"customTextName":"Other:","multioptions":false,"filterId":"ELOW1LTN","displayGroup":0,"rows":[],"key":[]},{"hideForCompany":false,"filterRequirements":["47EoZsOX","z2NMUZK2","G71w1XSC"],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12f5","qtype":"mc","text":"Which of the following devices do you use for online grocery shopping?","answers":[{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12f6","text":"Mobile Phone","exclusiveAnswer":false,"filterId":"X2i7XeaO","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12f7","text":"Tablet","exclusiveAnswer":false,"filterId":"HpTL4ccl","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12f8","text":"Desktop / Website","exclusiveAnswer":false,"filterId":"TzKy5rGa","random":true,"correctAnswer":false},{"filterRequirements":[],"filterNotRequirements":[],"_id":"6244325f952d8c0013db12f9","text":"Voice Assistant (E.g Alexa)","exclusiveAnswer":false,"filterId":"iwrMUDRu","random":true,"correctAnswer":false}],"allowCustomText":true,"customTextName":"Other:","multioptions":true,"filterId":"bRc8cmYw","displayGroup":0,"rows":[],"key":[]}],"title":"E-Food Spryker UK/DE/US","date":"2022-03-30T10:35:11.834Z","approvedDate":"2022-03-31T07:42:38.168Z","finishedDate":"2022-03-31T07:42:43.570Z","publicLink":"6uTtsBnuC","webapp":null,"tags":[{"_id":"624432607e359800081c0f8d","tag":"customer"},{"_id":"62443260f801e70009517364","tag":"kim"}]}',
    #   'incl_images': True,
    #   'english_lang': True}
    go(data)
    data = open("/tmp/survey_export.docx", "rb").read()
    encoded = base64.b64encode(data)
    return {
        'statusCode': 200,
        'headers': {"Content-Type": "application/docx",
                    "Content-Disposition": "attachment; filename=survey_export.docx"
        },
        'body': encoded,
        "isBase64Encoded": True
    }



def go(inputs):
    inputs = ast.literal_eval(inputs)
    print(inputs.keys())
    '''process inputs to generate word file displaying the survey archtecture'''
    t = inputs["raw_survey"]
    include_images = inputs["incl_images"]
    english_lang = inputs["english_lang"]
    include_filters = False
    # print(inputs)

    # layout = [
    #         [sg.Text("WARNING: So far, this is a quick and dirty solution.\n"
    #                  "The following information is not yet included in the final survey:\n"
    #                  "- multi filters on answers (if an answer has multiple filters, NO filter is shown)\n"
    #                  "- filter in matrix statements are currently not shown\n"
    #                  "- information whether question is randomized\n"
    #                  "- probably some other stuff - please tell Tim if you notice something")],
    #         [sg.Text("Paste raw text and wait a bit until I digested your input.")],
    #         [sg.Multiline(size=(50, 10), key='text_input')],
    #         [sg.Checkbox('Include images (takes +1 second per image)', enable_events=True, key = "CHECKBOX-IMAGE-CHECK")],
    #         [sg.Checkbox('Include answer filters (double check in the end - it is still buggy)', enable_events=True, key = "CHECKBOX-ANSWERTFILTER-CHECK")],
    #         [sg.Text("Select target folder where file should be saved"), sg.In(size=(15, 1), enable_events=True, key="-FOLDER-"),sg.FolderBrowse(button_color="white on black")],
    #         [sg.Button("Do the magic", button_color="white on darkgreen", size=(45,5))]
    #         ]

    # window = sg.Window("Export surveys", layout, keep_on_top=False)

    # while True:
    # dictionary of question types:
    dict_qtypes = {"mc": "Multiple Choice",
                   "freetext": "Offene Frage",
                   "info": "Infobox",
                   "matrix": "Matrix",
                   "likert": "Likert",
                   "numericslider": "Numerischer Slider / NPS",
                   "ranking": "Ranking",
                   "starslider": "Stars",
                   "propertyslider": "Präferenz-Slider",
                   "number": "Zahl (Freie Eingabe)",
                   "heatmap": "Heatmap",
                   "videoplay": "Audio/Video",
                   "photocaptur": "Fotoaufnahme"}

    if english_lang:
        dict_qtypes = {"mc": "Multiple Choice",
                       "freetext": "Open question",
                       "info": "Info box",
                       "matrix": "Matrix",
                       "likert": "Likert",
                       "imagecloud": "Multiple Choice (with images)",
                       "image": "Multiple Choice (with images and text)",
                       "numericslider": "Numeric slider / NPS",
                       "ranking": "Ranking",
                       "starslider": "Stars",
                       "propertyslider": "Preference slider",
                       "number": "Number (Open entry)",
                       "heatmap": "Heatmap",
                       "videoplay": "Audio/Video",
                       "photocaptur": "Take photo"}

    # event, values = window.read()
    # if event == "Exit" or event == sg.WIN_CLOSED:
    #     break

    # select target folder for exporting the word file
    # if event == "-FOLDER-":
    #     folder = values["-FOLDER-"]
    #     folder = folder.replace('/', '\\')

    # Read text-value
    # if event == "Do the magic":
    #     event, value = window.read() #read inserted values -> read shrinc factor
    json_string = t.rstrip()
    survey_raw = json.loads(json_string)

    document = Document()

    # General style
    style = document.styles['Normal']
    font = style.font
    font.name = 'Roboto'
    font.size = Pt(10)
    paragraph_format = style.paragraph_format
    # Add header for first page with table (logo on the left, address on the right)
    header = document.sections[0].first_page_header
    document.sections[0].different_first_page_header_footer = True
    htable = header.add_table(1, 4, Inches(6.25))
    htab_cells = htable.rows[0].cells
    ht0 = htab_cells[0].paragraphs[0]  # cell including the logo
    kh = ht0.add_run(style=None)
    kh.add_picture("Appinio-Logo.png", width=Inches(1.401575))
    # cell including address and contact information
    ht1 = htab_cells[3].paragraphs[0]
    run = ht1.add_run(
        "APPINIO GmbH\nGroße Theaterstraße31\n20354 Hamburg\n\ncontact@appinio.com\n+49 40 / 413 49 710\nwww.appinio.com")
    run.font.name = "Roboto"
    run.font.size = Pt(8)
    run.font.color.rgb = RGBColor(69, 107, 132)
    ht1.alignment = WD_ALIGN_PARAGRAPH.LEFT
    # header for following pages only with Appinio logo
    header = document.sections[0].header
    document.sections[0].different_first_page_header_footer = True
    htable = header.add_table(2, 2, Inches(6))
    htab_cells = htable.rows[0].cells
    ht0 = htab_cells[0].paragraphs[0]  # cell including the logo
    kh = ht0.add_run(style=None)
    kh.add_picture("Appinio-Logo.png", width=Inches(1.401575))
    # Add title and date
    document.add_paragraph()
    para = document.add_paragraph()
    run = para.add_run('\t\t Hamburg, ' +
                       str(date.today().strftime("%d.%m.%Y")))
    run.font.color.rgb = RGBColor(69, 107, 132)
    para.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    document.add_paragraph()

    run = document.add_paragraph().add_run(survey_raw['title'])
    font = run.font
    font.name = 'Roboto Medium'
    font.size = Pt(14)
    font.color.rgb = RGBColor(5, 49, 73)
    document.add_paragraph()

    #style = document.styles['Normal']
    #font = style.font
    #font.name = 'Roboto'
    #font.size = Pt(10)
    #paragraph_format = style.paragraph_format

    # Add header
    # document.add_paragraph(survey_raw['title'])
    # document.add_paragraph()

    # add table
    table = document.add_table(1, 3)
    table.style = 'TableGrid'

    # populate header row
    if english_lang:
        heading_cells = table.rows[0].cells
        heading_cells[0].paragraphs[0].add_run('Question no.').bold = True
        heading_cells[1].paragraphs[0].add_run('Survey').bold = True
        heading_cells[2].paragraphs[0].add_run('Question type').bold = True

    else:
        heading_cells = table.rows[0].cells
        heading_cells[0].paragraphs[0].add_run('Frage').bold = True
        heading_cells[1].paragraphs[0].add_run('Fragebogen').bold = True
        heading_cells[2].paragraphs[0].add_run('Fragetyp').bold = True

    # contents
    info_no = 1
    question_no = 1

    for i in range(len(survey_raw['questions'])):  # question number
        if survey_raw['questions'][i]['hideForCompany']:
            continue
        cells = table.add_row().cells

        # cell 1 -------------
        if survey_raw['questions'][i]['qtype'] == 'info' or survey_raw['questions'][i]['qtype'] == 'videoplay':
            cells[0].paragraphs[0].add_run("Info "+str(info_no)).bold = True
            info_no += 1

        if survey_raw['questions'][i]['qtype'] != 'info' and survey_raw['questions'][i]['qtype'] != 'videoplay':
            cells[0].paragraphs[0].add_run("F"+str(question_no)).bold = True
            question_no += 1

        # cell 2 -------------
        # question wording -------------
        cells[1].paragraphs[0].add_run(
            survey_raw['questions'][i]['text']).bold = True
        paragraph_format.space_before = Pt(2)
        paragraph_format.space_after = Pt(2)

        # Include instructions for participants
        # check whether instructions for participants exist
        if "help" in survey_raw['questions'][i]:
            cells[1].add_paragraph(str(survey_raw['questions'][i]['help']))

        # Include image
        if include_images:
            # check whether image URL exist
            if "media" in survey_raw['questions'][i]:
                image_url = str(survey_raw['questions'][i]['media'])
                response = requests.get(image_url)
                binary_img = BytesIO(response.content)
                paragraph = cells[1].paragraphs[0]
                run = paragraph.add_run()
                run.add_picture(binary_img, width=Inches(2))
                time.sleep(1)

        cells[1].add_paragraph()

        # Answers -------------
        if survey_raw['questions'][i]['qtype'] == 'matrix':
            if english_lang:
                cells[1].add_paragraph("Answers:").bold = True
            else:
                cells[1].add_paragraph("Antworten:").bold = True

        # Answer text and letter
        answer_letter = 65  # because chr(65) = 'A'

        # Check for randomization
        random_answer = False
        random_answer_text = " "
        for j in range(len(survey_raw['questions'][i]['answers'])):
            if "random" in survey_raw['questions'][i]['answers'][j]:
                if survey_raw['questions'][i]['answers'][j]["random"] == True:
                    random_answer = True

        # If randomized:
        if random_answer == True:
            for j in range(len(survey_raw['questions'][i]['answers'])):  # answers
                if survey_raw['questions'][i]['answers'][j]["random"] == False:
                    if english_lang:
                        random_answer_text = " (not randomized)"
                    else:
                        random_answer_text = " (nicht randomisiert)"

                answer_filter_text = " "
                if include_filters:

                    # Filter IF
                    if survey_raw['questions'][i]['answers'][j]["filterRequirements"] != []:
                        for k in range(len(survey_raw['questions'][i]['answers'][j]["filterRequirements"])):
                            filter_id = str(
                                survey_raw['questions'][i]['answers'][j]["filterRequirements"][k])
                            for l in range(len(survey_raw['questions'])):
                                for m in range(len(survey_raw['questions'][l]['answers'])):
                                    if filter_id in survey_raw['questions'][l]['answers'][m]["filterId"]:
                                        infoxboxes_until_here = info_no - 1
                                        filter_question_no = 1 + l - infoxboxes_until_here
                                        filter_answer_letter = 65 + m
                                        answer_filter_text = str(
                                            " (IF F"+str(filter_question_no)+str(chr(filter_answer_letter))+")"+random_answer_text)
                                for n in range(len(survey_raw['questions'][l]['key'])):
                                    if filter_id in survey_raw['questions'][l]['key'][n]["filterId"]:
                                        infoxboxes_until_here = info_no - 1
                                        filter_question_no = 1 + l - infoxboxes_until_here
                                        filter_answer_letter = 65 + n
                                        answer_filter_text = str(
                                            " (IF F"+str(filter_question_no)+str(chr(filter_answer_letter))+")"+random_answer_text)

                    # Filter IF NOT
                    if survey_raw['questions'][i]['answers'][j]["filterNotRequirements"] != []:
                        for k in range(len(survey_raw['questions'][i]['answers'][j]["filterNotRequirements"])):
                            filter_id = str(
                                survey_raw['questions'][i]['answers'][j]["filterNotRequirements"][k])
                            for l in range(len(survey_raw['questions'])):
                                for m in range(len(survey_raw['questions'][l]['answers'])):
                                    if filter_id in survey_raw['questions'][l]['answers'][m]["filterId"]:
                                        infoxboxes_until_here = info_no - 1
                                        filter_question_no = 1 + l - infoxboxes_until_here
                                        filter_answer_letter = 65 + m
                                        answer_filter_text = str(
                                            " (IF NOT F"+str(filter_question_no)+str(chr(filter_answer_letter))+")"+random_answer_text)
                                for n in range(len(survey_raw['questions'][l]['key'])):
                                    if filter_id in survey_raw['questions'][l]['key'][n]["filterId"]:
                                        infoxboxes_until_here = info_no - 1
                                        filter_question_no = 1 + l - infoxboxes_until_here
                                        filter_answer_letter = 65 + n
                                        answer_filter_text = str(
                                            " (IF NOT F"+str(filter_question_no)+str(chr(filter_answer_letter))+")"+random_answer_text)

                answer_text = str(chr(
                    answer_letter)+": "+survey_raw['questions'][i]['answers'][j]['text'] + answer_filter_text+random_answer_text)
                cells[1].add_paragraph(answer_text)
                answer_letter += 1

        if random_answer == False:
            for j in range(len(survey_raw['questions'][i]['answers'])):  # answers
                answer_filter_text = " "
                if include_filters:

                    # Filter IF
                    if survey_raw['questions'][i]['answers'][j]["filterRequirements"] != []:
                        for k in range(len(survey_raw['questions'][i]['answers'][j]["filterRequirements"])):
                            filter_id = str(
                                survey_raw['questions'][i]['answers'][j]["filterRequirements"][k])
                            for l in range(len(survey_raw['questions'])):
                                for m in range(len(survey_raw['questions'][l]['answers'])):
                                    if filter_id in survey_raw['questions'][l]['answers'][m]["filterId"]:
                                        if survey_raw['questions'][i]['qtype'] == 'info' or survey_raw['questions'][i]['qtype'] == 'videoplay':
                                            infoxboxes_until_here = info_no
                                        else:
                                            infoxboxes_until_here = info_no - 1
                                        filter_question_no = 1 + l - infoxboxes_until_here
                                        filter_answer_letter = 65 + m
                                        answer_filter_text = str(
                                            " (IF F"+str(filter_question_no)+str(chr(filter_answer_letter))+")")
                                for n in range(len(survey_raw['questions'][l]['key'])):
                                    if filter_id in survey_raw['questions'][l]['key'][n]["filterId"]:
                                        if survey_raw['questions'][i]['qtype'] == 'info' or survey_raw['questions'][i]['qtype'] == 'videoplay':
                                            infoxboxes_until_here = info_no
                                        else:
                                            infoxboxes_until_here = info_no - 1
                                        filter_question_no = 1 + l - infoxboxes_until_here
                                        filter_answer_letter = 65 + n
                                        answer_filter_text = str(
                                            " (IF F"+str(filter_question_no)+str(chr(filter_answer_letter))+")")

                    # Filter IF NOT
                    if survey_raw['questions'][i]['answers'][j]["filterNotRequirements"] != []:
                        for k in range(len(survey_raw['questions'][i]['answers'][j]["filterNotRequirements"])):
                            filter_id = str(
                                survey_raw['questions'][i]['answers'][j]["filterNotRequirements"][k])
                            for l in range(len(survey_raw['questions'])):
                                for m in range(len(survey_raw['questions'][l]['answers'])):
                                    if filter_id in survey_raw['questions'][l]['answers'][m]["filterId"]:
                                        infoxboxes_until_here = info_no - 1
                                        filter_question_no = 1 + l - infoxboxes_until_here
                                        filter_answer_letter = 65 + m
                                        answer_filter_text = str(
                                            " (IF NOT F"+str(filter_question_no)+str(chr(filter_answer_letter))+")")
                                for n in range(len(survey_raw['questions'][l]['key'])):
                                    if filter_id in survey_raw['questions'][l]['key'][n]["filterId"]:
                                        infoxboxes_until_here = info_no - 1
                                        filter_question_no = 1 + l - infoxboxes_until_here
                                        filter_answer_letter = 65 + n
                                        answer_filter_text = str(
                                            " (IF NOT F"+str(filter_question_no)+str(chr(filter_answer_letter))+")")

                answer_text = str(chr(
                    answer_letter)+": "+survey_raw['questions'][i]['answers'][j]['text'] + answer_filter_text)
                cells[1].add_paragraph(answer_text)
                answer_letter += 1

        # Anweisung für Teilnehmer
        if "allowCustomText" in survey_raw['questions'][i]:
            try:
                if survey_raw['questions'][i]["allowCustomText"] == True:
                    freetex_answer_test = survey_raw['questions'][i]["customTextName"]
                    if survey_raw['questions'][i]['answers'][j]["random"] == False:
                        if english_lang:
                            cells[1].add_paragraph(
                                str(str(freetex_answer_test)+" (Freetext)"))
                        else:
                            cells[1].add_paragraph(
                                str(str(freetex_answer_test)+" (Freitext)"))

            except: # pylint: disable=W0702
                pass

        # info texts
        if survey_raw['questions'][i]['qtype'] == 'info' or survey_raw['questions'][i]['qtype'] == 'videoplay':
            try:
                cells[1].add_paragraph(
                    str(survey_raw['questions'][i]['infoText']))
            except: # pylint: disable=W0702
                pass

        # include images
        for j in range(len(survey_raw['questions'][i]['answers'])):
            if include_images:
                # check whether image URL exist
                if "imageUrl" in survey_raw['questions'][i]['answers'][j]:
                    image_url = str(
                        survey_raw['questions'][i]['answers'][j]['imageUrl'])
                    print(image_url)
                    response = requests.get(image_url)
                    binary_img = BytesIO(response.content)
                    paragraph = cells[1].paragraphs[0]
                    run = paragraph.add_run()
                    run.add_picture(binary_img, width=Inches(2))
                    time.sleep(1)

        # matrix scale items
        random_mat_items = False
        random_mat_items_text = " "
        for j in range(len(survey_raw['questions'][i]['rows'])):
            if "random" in survey_raw['questions'][i]['rows'][j]:
                if survey_raw['questions'][i]['rows'][j]["random"] == True:
                    random_mat_items = True

        # if randomized
        if random_mat_items == True:
            for j in range(len(survey_raw['questions'][i]['rows'])):  # answers
                if survey_raw['questions'][i]['rows'][j]["random"] == False:
                    if english_lang:
                        random_mat_items_text = " (not randomized)"
                    else:
                        random_mat_items_text = " (nicht randomisiert)"

            answer_letter = 65  # because chr(65) = 'A'
            if survey_raw['questions'][i]['rows'] != []:  # Test whether matrix items exist
                cells[1].add_paragraph()
                cells[1].add_paragraph("Items:")
                # matrix items
                for k in range(len(survey_raw['questions'][i]['rows'])):
                    item_text = str(chr(
                        answer_letter)+": "+survey_raw['questions'][i]['rows'][k]['text']+random_mat_items_text)
                    cells[1].add_paragraph(item_text)
                    answer_letter += 1

        # if not randomized
        if random_mat_items == False:

            answer_letter = 65  # because chr(65) = 'A'
            if survey_raw['questions'][i]['rows'] != []:  # Test whether matrix items exist
                cells[1].add_paragraph()
                cells[1].add_paragraph("Items:")
                # matrix items
                for k in range(len(survey_raw['questions'][i]['rows'])):
                    item_text = str(chr(answer_letter)+": " +
                                    survey_raw['questions'][i]['rows'][k]['text'])
                    cells[1].add_paragraph(item_text)
                    answer_letter += 1

        # likert scale
        answer_letter = 65  # because chr(65) = 'A'
        if survey_raw['questions'][i]['key'] != []:  # Test whether matrix items exist
            for k in range(len(survey_raw['questions'][i]['key'])):  # matrix items
                item_text = str(chr(answer_letter)+": " +
                                survey_raw['questions'][i]['key'][k]['text'])
                cells[1].add_paragraph(item_text)
                answer_letter += 1

        # cell 3 -------------
        # "Fragetyp" -------------

        if survey_raw['questions'][i]['qtype'] != "mc":
            for abbreviation, new_label in dict_qtypes.items():
                if abbreviation == survey_raw['questions'][i]['qtype']:
                    question_type = survey_raw['questions'][i]['qtype'].replace(
                        abbreviation, new_label)
                    try:
                        cells[2].paragraphs[0].add_run(question_type)
                    except:  # pylint: disable=W0702
                        cells[2].paragraphs[0].add_run("missing question type")

        # if survey_raw['questions'][i]['qtype'] == "mc":
        else:
            if 'multioptions' in survey_raw['questions'][i]:
                if survey_raw['questions'][i]['multioptions'] == False:
                    cells[2].paragraphs[0].add_run("Single Choice")
                else:
                    cells[2].paragraphs[0].add_run("Multiple Choice")

        # Randomisation
        if random_mat_items == True:
            if english_lang:
                cells[2].add_paragraph("(Items randomized)")
            else:
                cells[2].add_paragraph("(Items randomisiert)")

        if random_answer == True:
            if english_lang:
                cells[2].add_paragraph("(Answers randomized)")
            else:
                cells[2].add_paragraph("(Antworten randomisiert)")

        # Max options
        if "maxOptions" in survey_raw['questions'][i]:
            if english_lang:
                cells[2].add_paragraph(
                    "Max Answers: "+str(survey_raw['questions'][i]['maxOptions']))
            else:
                cells[2].add_paragraph(
                    "Max Antworten: "+str(survey_raw['questions'][i]['maxOptions']))

        # Min options
        if "minOptions" in survey_raw['questions'][i]:
            if english_lang:
                cells[2].add_paragraph(
                    "Min Answers: "+str(survey_raw['questions'][i]['minOptions']))
            else:
                cells[2].add_paragraph(
                    "Min Antworten: "+str(survey_raw['questions'][i]['minOptions']))

        # Do filter exist?
        if survey_raw['questions'][i]["filterRequirements"] != [] or survey_raw['questions'][i]["filterNotRequirements"] != []:
            cells[2].add_paragraph()
            cells[2].add_paragraph("Filter:")

        # Filter IF
        if survey_raw['questions'][i]["filterRequirements"] != []:
            for k in range(len(survey_raw['questions'][i]["filterRequirements"])):
                filter_id = str(survey_raw['questions']
                                [i]["filterRequirements"][k])
                for l in range(len(survey_raw['questions'])):
                    if survey_raw['questions'][l]['answers'] != []:
                        for m in range(len(survey_raw['questions'][l]['answers'])):
                            if filter_id in survey_raw['questions'][l]['answers'][m]["filterId"]:
                                if survey_raw['questions'][l]['qtype'] == 'info' or survey_raw['questions'][l]['qtype'] == 'videoplay':
                                    infoxboxes_until_here = info_no
                                else:
                                    infoxboxes_until_here = info_no - 1
                                print("Infoboxes:" + str(infoxboxes_until_here))
                                print("l:"+str())
                                filter_question_no = 1 + l - infoxboxes_until_here
                                print("filter_qestion:" +
                                      str(filter_question_no))
                                filter_answer_letter = 65 + m
                                cells[2].add_paragraph(
                                    "IF F"+str(filter_question_no)+str(chr(filter_answer_letter)))
                    elif survey_raw['questions'][l]['key'] != []:
                        for n in range(len(survey_raw['questions'][l]['key'])):
                            if filter_id in survey_raw['questions'][l]['key'][n]["filterId"]:
                                if survey_raw['questions'][l]['qtype'] == 'info' or survey_raw['questions'][l]['qtype'] == 'videoplay':
                                    infoxboxes_until_here = info_no
                                else:
                                    infoxboxes_until_here = info_no - 1
                                filter_question_no = 1 + l - infoxboxes_until_here
                                filter_answer_letter = 65 + n
                                cells[2].add_paragraph(
                                    "IF F"+str(filter_question_no)+str(chr(filter_answer_letter)))

        # Filter IF NOT
        elif survey_raw['questions'][i]["filterNotRequirements"] != []:
            for k in range(len(survey_raw['questions'][i]["filterNotRequirements"])):
                filter_id = str(survey_raw['questions']
                                [i]["filterNotRequirements"][k])
                for l in range(len(survey_raw['questions'])):
                    if survey_raw['questions'][l]['answers'] != []:
                        for m in range(len(survey_raw['questions'][l]['answers'])):
                            if filter_id in survey_raw['questions'][l]['answers'][m]["filterId"]:
                                infoxboxes_until_here = info_no - 1
                                filter_question_no = 1 + l - infoxboxes_until_here
                                filter_answer_letter = 65 + m
                                cells[2].add_paragraph(
                                    "IF NOT F"+str(filter_question_no)+str(chr(filter_answer_letter)))
                    if survey_raw['questions'][l]['key'] != []:
                        for n in range(len(survey_raw['questions'][l]['key'])):
                            if filter_id in survey_raw['questions'][l]['key'][n]["filterId"]:
                                infoxboxes_until_here = info_no - 1
                                filter_question_no = 1 + l - infoxboxes_until_here
                                filter_answer_letter = 65 + n
                                cells[2].add_paragraph(
                                    "IF NOT F"+str(filter_question_no)+str(chr(filter_answer_letter)))

    # Layout stuff
    for row in table.rows:
        for cell, width in zip(row.cells, (Inches(0.72), Inches(5.1), Inches(1.50))):
            cell.width = width

    # Set a cell background (shading) color to RGB D9D9D9.
    shading1 = parse_xml(r'<w:shd {} w:fill="053149"/>'.format(nsdecls('w')))
    table.cell(0, 0)._tc.get_or_add_tcPr().append(shading1)
    shading2 = parse_xml(r'<w:shd {} w:fill="053149"/>'.format(nsdecls('w')))
    table.cell(0, 1)._tc.get_or_add_tcPr().append(shading2)
    shading3 = parse_xml(r'<w:shd {} w:fill="053149"/>'.format(nsdecls('w')))
    table.cell(0, 2)._tc.get_or_add_tcPr().append(shading3)

    # Save it
    file_name = survey_raw['title'].replace(":", "-")
    file_name = file_name.replace("/", "-")
    document.save('/tmp/survey_export.docx')
